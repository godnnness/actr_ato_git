# Testing the Git Integration
# TODO: Create a new simpler runner with specific predefined flags for trained NNs.
# TODO: It should run till it finds obs.last so you pre-specify the full episodes.