# Takover-Model
using resource-constrained job shop scheduling (from timnon) to imitate an ACT-R version of a human taking over from highly automated to manual driving.
