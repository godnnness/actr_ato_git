# ACT-Touch
Provides a simulated mobile multi-touchscreen GUI and associated user’s motor movements to Monte Carlo simulations using the ACT-R computational cognitive architecture theory and software implementation. Now distributed with ACT-R. http://act-r.psy.cmu.edu/
