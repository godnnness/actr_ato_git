SGOMS
=====

SGOMS is a system for using ACT-R to model Human Expertise
