import ccm
ccm.run('paired',20,threshold=[-1.25,-1.75,-2.25,-2.75])
