import ccm
ccm.run('paired',20,threshold=-2,latency=[0.3,0.35,0.4,0.45])
