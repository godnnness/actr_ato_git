import ccm
ccm.run('paired',50)
