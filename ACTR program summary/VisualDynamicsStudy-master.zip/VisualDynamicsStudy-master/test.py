import os

print(os.getcwd())

print(os.chdir("../"))

print(os.getcwd())
