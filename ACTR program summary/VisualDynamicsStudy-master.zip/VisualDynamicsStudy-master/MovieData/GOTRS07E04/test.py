import sys

argument = sys.argv[1]
file_name = argument.split("/")[-1]

print(file_name)